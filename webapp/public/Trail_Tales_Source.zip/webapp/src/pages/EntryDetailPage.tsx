import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { JournalEntry } from "@/components/JournalEntry";
import { TrailMap } from "@/components/TrailMap";
import { mockJournalEntries } from "@/data/journalEntries";
import { ArrowLeft } from "lucide-react";

export function EntryDetailPage() {
  const { id } = useParams<{ id: string }>();
  const entry = mockJournalEntries.find((e) => e.id === id);

  if (!entry) {
    return (
      <div className="min-h-screen py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Entry Not Found</h1>
          <p className="text-muted-foreground mb-8">
            The journal entry you're looking for doesn't exist.
          </p>
          <Link to="/timeline">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Timeline
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 md:py-12">
      <div className="container mx-auto px-4">
        {/* Back button */}
        <div className="mb-6">
          <Link to="/timeline">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Timeline
            </Button>
          </Link>
        </div>

        {/* Main content */}
        <div className="max-w-4xl mx-auto">
          <JournalEntry entry={entry} showFullContent={true} />

          {/* Map section */}
          <div className="mt-12">
            <h3 className="text-2xl font-bold mb-4">Today's Route</h3>
            <TrailMap entries={[entry]} selectedEntry={entry} height="400px" />
          </div>

          {/* Navigation */}
          <div className="mt-12 pt-8 border-t flex justify-between items-center">
            <Link to="/timeline">
              <Button variant="outline">
                <ArrowLeft className="mr-2 h-4 w-4" />
                All Entries
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
