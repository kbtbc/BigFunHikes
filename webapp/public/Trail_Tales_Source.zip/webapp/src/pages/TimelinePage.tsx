import { Timeline } from "@/components/Timeline";
import { mockJournalEntries } from "@/data/journalEntries";

export function TimelinePage() {
  return (
    <div className="min-h-screen py-12 md:py-16">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Trail Journal
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Daily updates, stories, and reflections from the Appalachian Trail.
            Each entry captures the beauty, challenges, and magic of the journey.
          </p>
        </div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto">
          <Timeline entries={mockJournalEntries} />
        </div>

        {/* Empty state (for when there are no entries) */}
        {mockJournalEntries.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-muted-foreground text-lg">
              No journal entries yet. Check back soon!
            </p>
          </div>
        ) : null}
      </div>
    </div>
  );
}
