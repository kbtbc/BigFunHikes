import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { TrailMap } from "@/components/TrailMap";
import { Stats } from "@/components/Stats";
import { JournalEntry } from "@/components/JournalEntry";
import { mockJournalEntries, trailStats } from "@/data/journalEntries";
import { ArrowRight, Download, FileCode } from "lucide-react";

export function HomePage() {
  const latestEntry = mockJournalEntries[0];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[60vh] md:h-[70vh] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1464207687429-7505649dae38?w=1920&auto=format&fit=crop')",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-background"></div>
        </div>

        <div className="relative h-full flex items-center justify-center text-center px-4">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4 text-shadow">
              Trail Tales
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 text-shadow-sm">
              Following the white blazes from Georgia to Maine
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/timeline">
                <Button size="lg" className="font-semibold">
                  Read the Journal
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <Stats
            totalMiles={trailStats.totalMiles}
            milesCompleted={trailStats.milesCompleted}
            daysOnTrail={trailStats.daysOnTrail}
            averageDailyMiles={trailStats.averageDailyMiles}
            totalElevationGain={trailStats.totalElevationGain}
          />
        </div>
      </section>

      {/* Map Section */}
      <section className="py-12 md:py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-2">The Journey</h2>
          <p className="text-muted-foreground mb-8">
            Tracking my progress along the 2,190-mile Appalachian Trail
          </p>
          <TrailMap entries={mockJournalEntries} height="500px" />
        </div>
      </section>

      {/* Latest Entry Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">Latest Entry</h2>
              <p className="text-muted-foreground">
                The most recent update from the trail
              </p>
            </div>
            <Link to="/timeline">
              <Button variant="outline">
                View All Entries
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          <JournalEntry entry={latestEntry} />
          <div className="mt-6 text-center">
            <Link to={`/entry/${latestEntry.id}`}>
              <Button size="lg">
                Read Full Entry
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 md:py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Follow the Adventure
          </h2>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Join me on this incredible journey as I hike the entire Appalachian Trail,
            one step at a time.
          </p>
          <Link to="/timeline">
            <Button
              size="lg"
              variant="secondary"
              className="font-semibold"
            >
              Explore the Timeline
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              Trail Tales - Documenting the Appalachian Trail journey
            </p>
            <div className="flex items-center gap-6">
              <a
                href="/Trail_Tales_Source.zip"
                download="Trail_Tales_Source.zip"
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <FileCode className="h-4 w-4" />
                Download Source Code
              </a>
              <a
                href="/DEVELOPMENT_SPEC.md"
                download="Trail_Tales_Development_Spec.md"
                className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <Download className="h-4 w-4" />
                Download Dev Spec
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
