import { Link } from "react-router-dom";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, TrendingUp } from "lucide-react";
import { type JournalEntry } from "@/data/journalEntries";

interface TimelineProps {
  entries: JournalEntry[];
  className?: string;
}

export function Timeline({ entries, className = "" }: TimelineProps) {
  return (
    <div className={`relative ${className}`}>
      {/* Timeline line */}
      <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border hidden md:block"></div>

      {/* Timeline entries */}
      <div className="space-y-8">
        {entries.map((entry, index) => (
          <TimelineEntryCard key={entry.id} entry={entry} index={index} />
        ))}
      </div>
    </div>
  );
}

interface TimelineEntryCardProps {
  entry: JournalEntry;
  index: number;
}

function TimelineEntryCard({ entry, index }: TimelineEntryCardProps) {
  const formattedDate = format(new Date(entry.date), "MMM d, yyyy");

  return (
    <div
      className="relative animate-in fade-in slide-in-from-bottom-4"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      {/* Timeline dot */}
      <div className="absolute left-6 top-8 w-5 h-5 rounded-full bg-primary border-4 border-background z-10 hidden md:block"></div>

      {/* Content */}
      <Link to={`/entry/${entry.id}`} className="block md:ml-20">
        <Card className="border-2 shadow-md hover:shadow-xl transition-all hover:border-primary cursor-pointer group">
          <CardContent className="p-0">
            <div className="flex flex-col md:flex-row">
              {/* Thumbnail */}
              {entry.photos.length > 0 ? (
                <div className="w-full md:w-48 h-48 relative overflow-hidden rounded-t-lg md:rounded-l-lg md:rounded-tr-none">
                  <img
                    src={entry.photos[0].url}
                    alt={entry.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 left-2">
                    <Badge
                      variant="secondary"
                      className="font-outfit bg-black/50 text-white border-0"
                    >
                      Day {entry.day}
                    </Badge>
                  </div>
                </div>
              ) : null}

              {/* Content */}
              <div className="flex-1 p-4 md:p-6">
                <div className="mb-2">
                  <h3 className="text-xl font-bold mb-1 group-hover:text-primary transition-colors">
                    {entry.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">{formattedDate}</p>
                </div>

                <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
                  <MapPin className="h-4 w-4" />
                  <span className="line-clamp-1">
                    {entry.location.start} → {entry.location.end}
                  </span>
                </div>

                {/* Quick stats */}
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4 text-primary" />
                    <span className="font-semibold">{entry.miles} mi</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    <span className="font-semibold">{entry.elevationGain} ft</span>
                  </div>
                </div>

                {/* Preview text */}
                <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
                  {entry.content.split("\n\n")[1] || entry.content.split("\n\n")[0]}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    </div>
  );
}
