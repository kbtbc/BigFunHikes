import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, TrendingUp, Calendar } from "lucide-react";
import { type JournalEntry as JournalEntryType } from "@/data/journalEntries";

interface JournalEntryProps {
  entry: JournalEntryType;
  showFullContent?: boolean;
  className?: string;
}

export function JournalEntry({
  entry,
  showFullContent = false,
  className = "",
}: JournalEntryProps) {
  const formattedDate = format(new Date(entry.date), "MMMM d, yyyy");
  const previewContent = entry.content.split("\n").slice(0, 3).join("\n");

  return (
    <Card className={`border-2 shadow-lg hover:shadow-xl transition-shadow ${className}`}>
      <CardContent className="p-0">
        {/* Photos gallery */}
        {entry.photos.length > 0 ? (
          <div className="relative h-64 md:h-80 w-full overflow-hidden rounded-t-lg">
            <img
              src={entry.photos[0].url}
              alt={entry.photos[0].caption}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
              <p className="text-white text-sm text-shadow">
                {entry.photos[0].caption}
              </p>
            </div>
          </div>
        ) : null}

        <div className="p-6">
          {/* Header */}
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary" className="font-outfit">
                Day {entry.day}
              </Badge>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {formattedDate}
              </span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold mb-2">{entry.title}</h2>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>
                {entry.location.start} → {entry.location.end}
              </span>
            </div>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-4 mb-6 pb-6 border-b">
            <Stat icon={<MapPin />} label="Distance" value={`${entry.miles} mi`} />
            <Stat icon={<TrendingUp />} label="Elevation" value={`${entry.elevationGain} ft`} />
            <Stat
              icon={<MapPin />}
              label="Total Miles"
              value={`${entry.totalMiles} mi`}
            />
          </div>

          {/* Content */}
          <div className="prose prose-sm md:prose-base max-w-none prose-headings:font-outfit prose-headings:text-foreground prose-p:text-foreground prose-strong:text-foreground prose-a:text-primary prose-blockquote:text-muted-foreground prose-code:text-foreground">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {showFullContent ? entry.content : previewContent}
            </ReactMarkdown>
            {!showFullContent ? (
              <p className="text-muted-foreground italic mt-4">
                Read more to see the full entry...
              </p>
            ) : null}
          </div>

          {/* Additional photos */}
          {showFullContent && entry.photos.length > 1 ? (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              {entry.photos.slice(1).map((photo, index) => (
                <div key={index} className="relative rounded-lg overflow-hidden border-2 border-border">
                  <img
                    src={photo.url}
                    alt={photo.caption}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-2 bg-card/95 backdrop-blur-sm">
                    <p className="text-xs text-muted-foreground">{photo.caption}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}

interface StatProps {
  icon: React.ReactNode;
  label: string;
  value: string;
}

function Stat({ icon, label, value }: StatProps) {
  return (
    <div className="flex items-center gap-2">
      <div className="text-primary">{icon}</div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-semibold">{value}</p>
      </div>
    </div>
  );
}
