import { Hono } from "hono";
import { prisma } from "../prisma";
import type { Context } from "hono";

const statsRouter = new Hono<{
  Variables: {
    user: any;
    session: any;
  };
}>();

// Helper to check authentication
const requireAuth = (c: Context) => {
  const user = c.get("user");
  if (!user) {
    return c.json(
      { error: { message: "Unauthorized", code: "UNAUTHORIZED" } },
      401
    );
  }
  return null;
};

/**
 * GET /api/stats
 * Get overall hiking statistics for the authenticated user
 */
statsRouter.get("/", async (c) => {
  const authError = requireAuth(c);
  if (authError) return authError;

  const user = c.get("user");

  try {
    // Get all journal entries for the user
    const entries = await prisma.journalEntry.findMany({
      where: { userId: user.id },
      orderBy: { date: "desc" },
    });

    if (entries.length === 0) {
      return c.json({
        data: {
          totalMiles: 0,
          totalDays: 0,
          totalElevationGain: 0,
          averageMilesPerDay: 0,
          lastEntryDate: null,
        },
      });
    }

    // Calculate statistics
    const totalMiles = entries.reduce((sum, entry) => sum + entry.milesHiked, 0);
    const totalDays = entries.length;
    const totalElevationGain = entries.reduce(
      (sum, entry) => sum + (entry.elevationGain || 0),
      0
    );
    const averageMilesPerDay = totalMiles / totalDays;
    const lastEntryDate = entries[0]?.date.toISOString() || null;

    return c.json({
      data: {
        totalMiles,
        totalDays,
        totalElevationGain,
        averageMilesPerDay,
        lastEntryDate,
      },
    });
  } catch (error) {
    console.error("Error fetching stats:", error);
    return c.json(
      {
        error: {
          message: "Failed to fetch statistics",
          code: "FETCH_ERROR",
        },
      },
      500
    );
  }
});

export { statsRouter };
