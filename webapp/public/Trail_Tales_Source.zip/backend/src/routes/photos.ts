import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { prisma } from "../prisma";
import { createPhotoSchema } from "../types";
import type { Context } from "hono";

const photosRouter = new Hono<{
  Variables: {
    user: any;
    session: any;
  };
}>();

// Helper to check authentication
const requireAuth = (c: Context) => {
  const user = c.get("user");
  if (!user) {
    return c.json(
      { error: { message: "Unauthorized", code: "UNAUTHORIZED" } },
      401
    );
  }
  return null;
};

/**
 * POST /api/entries/:id/photos
 * Add a photo to a journal entry
 */
photosRouter.post(
  "/:id/photos",
  zValidator("json", createPhotoSchema),
  async (c) => {
    const authError = requireAuth(c);
    if (authError) return authError;

    const user = c.get("user");
    const entryId = c.req.param("id");
    const data = c.req.valid("json");

    try {
      // Verify that the journal entry exists and belongs to the user
      const entry = await prisma.journalEntry.findFirst({
        where: {
          id: entryId,
          userId: user.id,
        },
      });

      if (!entry) {
        return c.json(
          {
            error: {
              message: "Journal entry not found",
              code: "NOT_FOUND",
            },
          },
          404
        );
      }

      // Create the photo
      const photo = await prisma.photo.create({
        data: {
          ...data,
          journalEntryId: entryId,
        },
      });

      const formattedPhoto = {
        ...photo,
        createdAt: photo.createdAt.toISOString(),
      };

      return c.json({ data: formattedPhoto }, 201);
    } catch (error) {
      console.error("Error creating photo:", error);
      return c.json(
        {
          error: {
            message: "Failed to create photo",
            code: "CREATE_ERROR",
          },
        },
        500
      );
    }
  }
);

export { photosRouter };
