# Trail Tales - Development Specification

**Version**: 1.1
**Last Updated**: January 2026
**Status**: MVP Complete with Authentication

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [Frontend Specification](#3-frontend-specification)
4. [Backend Specification](#4-backend-specification)
5. [Database Schema](#5-database-schema)
6. [API Contracts](#6-api-contracts)
7. [Authentication System](#7-authentication-system)
8. [Design System](#8-design-system)
9. [Dependencies & Compatibility](#9-dependencies--compatibility)
10. [Known Issues & Solutions](#10-known-issues--solutions)
11. [Current Status](#11-current-status)
12. [Next Steps](#12-next-steps)

---

## 1. Project Overview

### Purpose
Trail Tales is a mobile-first web application for documenting Appalachian Trail (AT) thru-hikes. Users can record daily journal entries with markdown content, photos, GPS tracks, and statistics while visualizing their progress on an interactive map.

### Target Users
- Thru-hikers on the Appalachian Trail
- Section hikers documenting multi-day trips
- Trail enthusiasts wanting to share their journey

### Core Features (Implemented)
- Interactive Leaflet map with OpenTopoMap tiles
- Journal entries with rich markdown support
- Progress tracking (miles, elevation, days)
- Timeline view of all entries
- Statistics dashboard
- Mobile-responsive design
- GPX track visualization on map
- **User authentication with email OTP**
- **Protected routes for authenticated users**

---

## 2. Architecture

### System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend                              │
│                   React + Vite (Port 8000)                  │
│                                                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Pages     │  │ Components  │  │   Context/Hooks     │  │
│  │  - Home     │  │ - TrailMap  │  │  - AuthContext      │  │
│  │  - Timeline │  │ - Stats     │  │  - useEntries       │  │
│  │  - Entry    │  │ - Timeline  │  │  - useAuth          │  │
│  │  - Login    │  │ - Navbar    │  │                     │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ HTTP/JSON + Cookies
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                        Backend                               │
│                   Hono + Bun (Port 3000)                    │
│                                                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Routes    │  │    Auth     │  │      Prisma         │  │
│  │  /entries   │  │ Better Auth │  │   SQLite Client     │  │
│  │  /photos    │  │  Email OTP  │  │                     │  │
│  │  /stats     │  │             │  │                     │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                       Database                               │
│                   SQLite (dev.db)                           │
│                                                              │
│   Users │ Sessions │ Accounts │ JournalEntries │ Photos    │
└─────────────────────────────────────────────────────────────┘
```

### Directory Structure

```
/home/user/workspace/
├── CLAUDE.md                    # Project instructions
├── DEVELOPMENT_SPEC.md          # This document
├── README.md                    # User-facing documentation
│
├── webapp/                      # Frontend application
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.ts
│   ├── tsconfig.json
│   ├── index.html
│   └── src/
│       ├── main.tsx             # Entry point
│       ├── App.tsx              # Router + providers
│       ├── index.css            # Design system (CSS variables)
│       ├── context/
│       │   └── AuthContext.tsx  # Authentication state & methods
│       ├── components/
│       │   ├── TrailMap.tsx     # Leaflet map (native, not react-leaflet)
│       │   ├── Stats.tsx        # Progress statistics
│       │   ├── Timeline.tsx     # Entry timeline
│       │   ├── JournalEntry.tsx # Entry display
│       │   ├── Navbar.tsx       # Navigation with auth UI
│       │   ├── ProtectedRoute.tsx # Auth guard component
│       │   └── ui/              # shadcn/ui components
│       ├── pages/
│       │   ├── HomePage.tsx
│       │   ├── LoginPage.tsx    # Email OTP login flow
│       │   ├── TimelinePage.tsx
│       │   ├── EntryDetailPage.tsx
│       │   └── NotFound.tsx
│       ├── hooks/
│       │   ├── use-toast.ts
│       │   └── use-entries.ts   # React Query hooks for entries API
│       ├── data/
│       │   └── journalEntries.ts # Mock data (for public view)
│       └── lib/
│           ├── utils.ts
│           └── api.ts           # Typed API client
│
└── backend/                     # Backend API
    ├── package.json
    ├── tsconfig.json
    └── src/
        ├── index.ts             # Hono app entry
        ├── auth.ts              # Better Auth config
        ├── prisma.ts            # Prisma client
        ├── env.ts               # Environment validation
        ├── types.ts             # Zod schemas (shared contracts)
        └── routes/
            ├── entries.ts       # Journal CRUD
            ├── photos.ts        # Photo management
            ├── stats.ts         # Statistics endpoint
            └── sample.ts        # Sample/health routes
    └── prisma/
        ├── schema.prisma        # Database schema
        └── dev.db               # SQLite database file
```

---

## 3. Frontend Specification

### Tech Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| React | 18.3.1 | UI framework |
| Vite | 5.4.21 | Build tool & dev server |
| TypeScript | 5.9.3 | Type safety |
| Tailwind CSS | 3.4.18 | Styling |
| shadcn/ui | Latest | Component library |
| Leaflet | 1.9.4 | Map rendering |
| React Router | 6.30.2 | Client-side routing |
| TanStack Query | 5.90.10 | Server state management |
| react-markdown | 10.1.0 | Markdown rendering |
| Framer Motion | 12.23.28 | Animations |
| Lucide React | 0.462.0 | Icons |

### Key Configuration Files

**vite.config.ts**
```typescript
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import { vibecodePlugin } from "@vibecodeapp/webapp/plugin";
import path from "path";

export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8000,
    allowedHosts: true,
  },
  plugins: [
    react(),
    mode === "development" && vibecodePlugin(),
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));
```

**tailwind.config.ts**
- Uses CSS variables for theming (light/dark mode)
- Custom font families: Outfit (headings), Inter (body)
- Custom animations: accordion, shimmer-sweep, glow-pulse
- Extended color palette with semantic naming

### Component Specifications

#### TrailMap.tsx (Critical Component)
**Purpose**: Interactive map showing trail progress and journal entry locations.

**Implementation**: Uses **native Leaflet** (NOT react-leaflet due to compatibility issues).

```typescript
// Key imports
import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Pattern: useRef for map container + useEffect for initialization
const mapRef = useRef<HTMLDivElement>(null);
const mapInstanceRef = useRef<L.Map | null>(null);

useEffect(() => {
  if (!mapRef.current || mapInstanceRef.current) return;
  const map = L.map(mapRef.current).setView(defaultCenter, defaultZoom);
  mapInstanceRef.current = map;
  // ... add layers, markers, etc.
  return () => { map.remove(); mapInstanceRef.current = null; };
}, []);
```

**Props**:
- `entries?: JournalEntry[]` - Entries to display on map
- `selectedEntry?: JournalEntry` - Highlighted entry
- `height?: string` - Container height (default: "500px")
- `className?: string` - Additional CSS classes

**Features**:
- OpenTopoMap tiles (free, no API limits)
- Green markers for start points
- Red markers for end points
- Polyline for GPX tracks
- Auto-fit bounds to show all entries
- Click popups with entry details

#### Navbar.tsx
**Purpose**: Top navigation with authentication UI.

**Features**:
- Logo and app branding
- Navigation links (Home, Journal)
- Auth state display (Sign in button or user dropdown)
- Sign out functionality

#### Stats.tsx
**Purpose**: Display hiking progress and statistics.

**Props**:
```typescript
interface StatsProps {
  totalMiles: number;      // Total AT miles (2190)
  milesCompleted: number;  // Miles hiked so far
  daysOnTrail: number;     // Number of hiking days
  averageDailyMiles: number;
  totalElevationGain: number;
}
```

#### JournalEntry.tsx
**Purpose**: Render a single journal entry with markdown content.

**Features**:
- Markdown rendering with react-markdown + remark-gfm
- Photo gallery display
- Entry metadata (date, miles, elevation)

### Page Structure

| Page | Route | Auth Required | Description |
|------|-------|---------------|-------------|
| HomePage | `/` | No | Hero, stats, map, latest entry |
| LoginPage | `/login` | No | Email OTP authentication |
| TimelinePage | `/timeline` | No | All entries in timeline format |
| EntryDetailPage | `/entry/:id` | No | Full entry with map |
| NotFound | `*` | No | 404 page |

### API Client (webapp/src/lib/api.ts)

```typescript
const API_BASE_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:3000";

// Response envelope - all app routes return { data: T }
async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
    credentials: "include",
  });

  if (!response.ok) {
    const json = await response.json().catch(() => null);
    throw new ApiError(json?.error?.message || "Request failed", response.status);
  }

  if (response.status === 204) return undefined as T;
  const json = await response.json();
  return json.data;
}

export const api = {
  get: <T>(endpoint: string) => request<T>(endpoint, { method: "GET" }),
  post: <T>(endpoint: string, data?: unknown) => request<T>(endpoint, {
    method: "POST",
    body: data ? JSON.stringify(data) : undefined,
  }),
  put: <T>(endpoint: string, data?: unknown) => request<T>(endpoint, {
    method: "PUT",
    body: data ? JSON.stringify(data) : undefined,
  }),
  delete: <T>(endpoint: string) => request<T>(endpoint, { method: "DELETE" }),
};

// Typed API functions
export const entriesApi = {
  list: (page = 1, pageSize = 10) =>
    api.get<JournalEntriesList>(`/api/entries?page=${page}&pageSize=${pageSize}`),
  get: (id: string) => api.get<JournalEntry>(`/api/entries/${id}`),
  create: (data: CreateJournalEntryInput) => api.post<JournalEntry>("/api/entries", data),
  update: (id: string, data: UpdateJournalEntryInput) => api.put<JournalEntry>(`/api/entries/${id}`, data),
  delete: (id: string) => api.delete<void>(`/api/entries/${id}`),
};

export const statsApi = {
  get: () => api.get<Stats>("/api/stats"),
};

export const photosApi = {
  add: (entryId: string, data: { url: string; caption?: string; order: number }) =>
    api.post<Photo>(`/api/entries/${entryId}/photos`, data),
  delete: (entryId: string, photoId: string) =>
    api.delete<void>(`/api/entries/${entryId}/photos/${photoId}`),
};
```

### React Query Hooks (webapp/src/hooks/use-entries.ts)

```typescript
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { entriesApi, statsApi } from "@/lib/api";

export const queryKeys = {
  entries: ["entries"] as const,
  entry: (id: string) => ["entries", id] as const,
  stats: ["stats"] as const,
};

export function useEntries(page = 1, pageSize = 50) {
  return useQuery({
    queryKey: [...queryKeys.entries, page, pageSize],
    queryFn: () => entriesApi.list(page, pageSize),
  });
}

export function useEntry(id: string) {
  return useQuery({
    queryKey: queryKeys.entry(id),
    queryFn: () => entriesApi.get(id),
    enabled: !!id,
  });
}

export function useStats() {
  return useQuery({
    queryKey: queryKeys.stats,
    queryFn: () => statsApi.get(),
  });
}

export function useCreateEntry() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateJournalEntryInput) => entriesApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.entries });
      queryClient.invalidateQueries({ queryKey: queryKeys.stats });
    },
  });
}

export function useUpdateEntry() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: UpdateJournalEntryInput }) =>
      entriesApi.update(id, data),
    onSuccess: (updatedEntry) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.entries });
      queryClient.setQueryData(queryKeys.entry(updatedEntry.id), updatedEntry);
    },
  });
}

export function useDeleteEntry() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => entriesApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.entries });
      queryClient.invalidateQueries({ queryKey: queryKeys.stats });
    },
  });
}
```

### Data Types (webapp/src/lib/api.ts)

```typescript
export interface Photo {
  id: string;
  journalEntryId: string;
  url: string;
  caption: string | null;
  order: number;
  createdAt: string;
}

export interface JournalEntry {
  id: string;
  userId: string;
  date: string;
  dayNumber: number;
  title: string;
  content: string;
  latitude: number | null;
  longitude: number | null;
  milesHiked: number;
  elevationGain: number | null;
  totalMilesCompleted: number;
  gpxData: string | null;
  createdAt: string;
  updatedAt: string;
  photos?: Photo[];
}

export interface CreateJournalEntryInput {
  date: string;
  dayNumber: number;
  title: string;
  content: string;
  latitude?: number | null;
  longitude?: number | null;
  milesHiked: number;
  elevationGain?: number | null;
  totalMilesCompleted: number;
  gpxData?: string | null;
}

export interface JournalEntriesList {
  entries: JournalEntry[];
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}

export interface Stats {
  totalMiles: number;
  totalDays: number;
  totalElevationGain: number;
  averageMilesPerDay: number;
  lastEntryDate: string | null;
}
```

---

## 4. Backend Specification

### Tech Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| Bun | Latest | JavaScript runtime |
| Hono | 4.6.0 | Web framework |
| Prisma | 6.x | ORM |
| SQLite | - | Database |
| Better Auth | 1.4.15 | Authentication |
| Zod | 4.1.11 | Schema validation |

### Entry Point (src/index.ts)

```typescript
import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { auth } from "./auth";

const app = new Hono<{
  Variables: {
    user: typeof auth.$Infer.Session.user | null;
    session: typeof auth.$Infer.Session.session | null;
  };
}>();

// CORS - validates against allowlist
const allowed = [
  /^http:\/\/localhost(:\d+)?$/,
  /^http:\/\/127\.0\.0\.1(:\d+)?$/,
  /^https:\/\/[a-z0-9-]+\.dev\.vibecode\.run$/,
  /^https:\/\/[a-z0-9-]+\.vibecode\.run$/,
];

app.use("*", cors({
  origin: (origin) => (origin && allowed.some((re) => re.test(origin)) ? origin : null),
  credentials: true,
}));

// Auth middleware - populates user/session for all routes
app.use("*", async (c, next) => {
  const session = await auth.api.getSession({ headers: c.req.raw.headers });
  c.set("user", session?.user ?? null);
  c.set("session", session?.session ?? null);
  await next();
});

// Routes
app.on(["GET", "POST"], "/api/auth/*", (c) => auth.handler(c.req.raw));
app.route("/api/entries", entriesRouter);
app.route("/api/entries", photosRouter);
app.route("/api/stats", statsRouter);

export default { port: 3000, fetch: app.fetch };
```

### Authentication (src/auth.ts)

```typescript
import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { emailOTP } from "better-auth/plugins";

export const auth = betterAuth({
  database: prismaAdapter(prisma, { provider: "sqlite" }),
  secret: env.BETTER_AUTH_SECRET,
  baseURL: env.BACKEND_URL,
  trustedOrigins: [
    "http://localhost:*",
    "http://127.0.0.1:*",
    "https://*.dev.vibecode.run",
    "https://*.vibecode.run",
    "https://*.vibecodeapp.com",
  ],
  plugins: [
    emailOTP({
      async sendVerificationOTP({ email, otp, type }) {
        if (type !== "sign-in") return;
        await vibecode.email.sendOTP({
          to: email,
          code: String(otp),
          fromName: "Appalachian Trail Journal",
        });
      },
    }),
  ],
  advanced: {
    crossSubDomainCookies: { enabled: true },
    disableCSRFCheck: true,
    defaultCookieAttributes: {
      sameSite: "none",
      secure: true,
      partitioned: true,
    },
  },
});
```

### Route Implementations

All routes follow the `{ data: ... }` envelope pattern for responses.

**Entries Router** (`/api/entries`):
- `GET /` - List entries (paginated, requires auth)
- `GET /:id` - Get single entry (requires auth)
- `POST /` - Create entry (requires auth)
- `PUT /:id` - Update entry (requires auth)
- `DELETE /:id` - Delete entry (requires auth)

**Photos Router** (`/api/entries/:id/photos`):
- `POST /` - Add photo to entry
- `DELETE /:photoId` - Remove photo

**Stats Router** (`/api/stats`):
- `GET /` - Get overall statistics

---

## 5. Database Schema

### Prisma Schema (prisma/schema.prisma)

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

model User {
  id            String         @id
  name          String
  email         String         @unique
  emailVerified Boolean        @default(false)
  image         String?
  createdAt     DateTime       @default(now())
  updatedAt     DateTime       @updatedAt
  sessions      Session[]
  accounts      Account[]
  journalEntries JournalEntry[]
}

model Session {
  id        String   @id
  expiresAt DateTime
  token     String   @unique
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  ipAddress String?
  userAgent String?
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
}

model Account {
  id                    String    @id
  accountId             String
  providerId            String
  userId                String
  user                  User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  accessToken           String?
  refreshToken          String?
  idToken               String?
  accessTokenExpiresAt  DateTime?
  refreshTokenExpiresAt DateTime?
  scope                 String?
  password              String?
  createdAt             DateTime  @default(now())
  updatedAt             DateTime  @updatedAt
}

model Verification {
  id         String   @id
  identifier String
  value      String
  expiresAt  DateTime
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
}

model JournalEntry {
  id                   String   @id @default(uuid())
  userId               String
  user                 User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  date                 DateTime
  dayNumber            Int
  title                String
  content              String
  latitude             Float?
  longitude            Float?
  milesHiked           Float
  elevationGain        Int?
  totalMilesCompleted  Float
  gpxData              String?
  createdAt            DateTime @default(now())
  updatedAt            DateTime @updatedAt
  photos               Photo[]

  @@index([userId, date])
  @@index([userId, dayNumber])
}

model Photo {
  id             String       @id @default(uuid())
  journalEntryId String
  journalEntry   JournalEntry @relation(fields: [journalEntryId], references: [id], onDelete: Cascade)
  url            String
  caption        String?
  order          Int
  createdAt      DateTime     @default(now())

  @@index([journalEntryId])
}
```

### Database Commands

```bash
# Push schema changes (dev/preview)
bunx prisma db push

# Generate Prisma client
bunx prisma generate

# Create migration (production)
bunx prisma migrate dev --create-only --name <migration-name>
bunx prisma migrate deploy

# View database
bunx prisma studio
```

---

## 6. API Contracts

### Shared Types (backend/src/types.ts)

All API contracts are defined as Zod schemas in `backend/src/types.ts`. Both frontend and backend can import from this file.

```typescript
// Create Journal Entry
export const createJournalEntrySchema = z.object({
  date: z.string().datetime(),
  dayNumber: z.number().int().positive(),
  title: z.string().min(1).max(500),
  content: z.string(),
  latitude: z.number().min(-90).max(90).nullable().optional(),
  longitude: z.number().min(-180).max(180).nullable().optional(),
  milesHiked: z.number().nonnegative(),
  elevationGain: z.number().int().nullable().optional(),
  totalMilesCompleted: z.number().nonnegative(),
  gpxData: z.string().nullable().optional(),
});

// Journal Entry Response
export const journalEntrySchema = z.object({
  id: z.string().uuid(),
  userId: z.string(),
  date: z.string().datetime(),
  dayNumber: z.number().int().positive(),
  title: z.string(),
  content: z.string(),
  latitude: z.number().nullable(),
  longitude: z.number().nullable(),
  milesHiked: z.number(),
  elevationGain: z.number().int().nullable(),
  totalMilesCompleted: z.number(),
  gpxData: z.string().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  photos: z.array(photoSchema).optional(),
});

// Error Response
export const errorSchema = z.object({
  error: z.object({
    message: z.string(),
    code: z.string().optional(),
  }),
});
```

### Response Envelope Pattern

All successful responses use the `{ data: ... }` envelope:

```json
// Success
{ "data": { ... } }

// Error
{ "error": { "message": "...", "code": "..." } }
```

### API Endpoints Summary

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/health` | No | Health check |
| POST | `/api/auth/email-otp/send-verification-otp` | No | Send OTP to email |
| POST | `/api/auth/sign-in/email-otp` | No | Verify OTP & sign in |
| GET | `/api/auth/get-session` | No | Get current session |
| POST | `/api/auth/sign-out` | Yes | Sign out |
| GET | `/api/entries` | Yes | List entries |
| GET | `/api/entries/:id` | Yes | Get entry |
| POST | `/api/entries` | Yes | Create entry |
| PUT | `/api/entries/:id` | Yes | Update entry |
| DELETE | `/api/entries/:id` | Yes | Delete entry |
| POST | `/api/entries/:id/photos` | Yes | Add photo |
| DELETE | `/api/entries/:id/photos/:photoId` | Yes | Remove photo |
| GET | `/api/stats` | Yes | Get statistics |

---

## 7. Authentication System

### Overview

Trail Tales uses **Better Auth** with the **Email OTP plugin** for passwordless authentication. Users sign in by entering their email, receiving a 6-digit code, and verifying it.

### Frontend Implementation

#### AuthContext (webapp/src/context/AuthContext.tsx)

```typescript
import { createContext, useContext, useState, useEffect, useCallback } from "react";

const API_BASE_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:3000";

interface User {
  id: string;
  name: string;
  email: string;
  emailVerified: boolean;
  image?: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Session {
  id: string;
  userId: string;
  token: string;
  expiresAt: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  sendOTP: (email: string) => Promise<void>;
  verifyOTP: (email: string, otp: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshSession: () => Promise<void>;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshSession = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/get-session`, {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        if (data.user && data.session) {
          setUser(data.user);
          setSession(data.session);
        } else {
          setUser(null);
          setSession(null);
        }
      }
    } catch (error) {
      setUser(null);
      setSession(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  const sendOTP = async (email: string) => {
    const response = await fetch(`${API_BASE_URL}/api/auth/email-otp/send-verification-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, type: "sign-in" }),
    });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.message || "Failed to send verification code");
    }
  };

  const verifyOTP = async (email: string, otp: string) => {
    const response = await fetch(`${API_BASE_URL}/api/auth/sign-in/email-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, otp }),
    });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.message || "Invalid verification code");
    }
    await refreshSession();
  };

  const signOut = async () => {
    try {
      await fetch(`${API_BASE_URL}/api/auth/sign-out`, {
        method: "POST",
        credentials: "include",
      });
    } finally {
      setUser(null);
      setSession(null);
    }
  };

  return (
    <AuthContext.Provider value={{
      user, session, isLoading, isAuthenticated: !!user,
      sendOTP, verifyOTP, signOut, refreshSession,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
}
```

### Authentication Flow

1. **User enters email** on login page
2. **Frontend calls** `POST /api/auth/email-otp/send-verification-otp` with `{ email, type: "sign-in" }`
3. **Backend sends OTP** via Vibecode email service
4. **User enters 6-digit code** in OTP input
5. **Frontend calls** `POST /api/auth/sign-in/email-otp` with `{ email, otp }`
6. **Backend validates OTP**, creates session, sets cookie
7. **Frontend refreshes session** via `GET /api/auth/get-session`
8. **User is now authenticated** - session stored in context

### Better Auth Endpoints (Correct Paths)

| Action | Method | Endpoint | Body |
|--------|--------|----------|------|
| Send OTP | POST | `/api/auth/email-otp/send-verification-otp` | `{ email, type: "sign-in" }` |
| Verify OTP & Sign In | POST | `/api/auth/sign-in/email-otp` | `{ email, otp }` |
| Get Session | GET | `/api/auth/get-session` | - |
| Sign Out | POST | `/api/auth/sign-out` | - |

### LoginPage Component (webapp/src/pages/LoginPage.tsx)

Two-step form:
1. **Email Step**: Input for email, submits to send OTP
2. **OTP Step**: 6-digit input using shadcn InputOTP component

Features:
- Loading states during API calls
- Error message display
- Resend code option
- Back button to change email
- Auto-submit when 6 digits entered
- Redirect to home after successful login

### ProtectedRoute Component (webapp/src/components/ProtectedRoute.tsx)

```typescript
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Loader2 } from "lucide-react";

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}
```

---

## 8. Design System

### Color Palette (HSL Format)

#### Light Mode
```css
--background: 60 29% 96%;        /* Earthy cream */
--foreground: 230 25% 18%;       /* Deep charcoal */
--primary: 146 26% 39%;          /* Forest green #4a7c59 */
--secondary: 106 45% 27%;        /* Deep forest #2d5016 */
--accent: 22 92% 67%;            /* Warm amber #f4a261 */
--destructive: 11 80% 62%;       /* Coral #e07a5f */
--muted: 60 15% 90%;
--muted-foreground: 230 15% 45%;
--border: 60 15% 85%;
```

#### Dark Mode
```css
--background: 230 25% 12%;
--foreground: 60 29% 96%;
--primary: 146 26% 45%;
--secondary: 106 45% 35%;
--accent: 22 92% 67%;
/* ... etc */
```

### Typography

```css
/* Headings */
font-family: 'Outfit', sans-serif;
/* Weights: 400, 500, 600, 700, 800 */

/* Body */
font-family: 'Inter', sans-serif;
/* Weights: 300, 400, 500, 600 */
```

**Google Fonts Import**:
```css
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap');
```

### Custom Utilities

```css
/* Gradient utilities */
.sunset-gradient {
  background: linear-gradient(135deg,
    hsl(var(--sunset-orange)) 0%,
    hsl(var(--sunset-coral)) 40%,
    hsl(var(--sunset-purple)) 70%,
    hsl(var(--sunset-blue)) 100%);
}

.forest-gradient {
  background: linear-gradient(135deg,
    hsl(var(--trail-forest)) 0%,
    hsl(var(--trail-forest-deep)) 100%);
}

/* Text shadows */
.text-shadow-sm { text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); }
.text-shadow { text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2); }
```

### Design Inspiration
- **Strava**: Progress tracking, statistics presentation
- **Notion**: Clean journaling interface
- **AllTrails**: Map aesthetics
- **National Park Service**: Earthy, outdoor color palette

---

## 9. Dependencies & Compatibility

### Frontend Dependencies (webapp/package.json)

```json
{
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-router-dom": "^6.30.2",
    "@tanstack/react-query": "^5.90.10",
    "leaflet": "^1.9.4",
    "react-leaflet": "^5.0.0",  // INSTALLED BUT NOT USED - see compatibility issues
    "react-markdown": "^10.1.0",
    "remark-gfm": "^4.0.1",
    "framer-motion": "^12.23.28",
    "lucide-react": "^0.462.0",
    "tailwind-merge": "^2.6.0",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "zod": "^3.25.76",
    // ... shadcn/ui dependencies (many @radix-ui packages)
  },
  "devDependencies": {
    "typescript": "^5.9.3",
    "vite": "^5.4.21",
    "@vitejs/plugin-react-swc": "^3.11.0",
    "tailwindcss": "^3.4.18",
    "@types/leaflet": "^1.9.21",
    // ... other dev deps
  }
}
```

### Backend Dependencies (backend/package.json)

```json
{
  "dependencies": {
    "hono": "4.6.0",
    "@hono/node-server": "1.12.0",
    "@hono/zod-validator": "^0.7.6",
    "@prisma/client": "6",
    "better-auth": "^1.4.15",
    "zod": "4.1.11",
    "@vibecodeapp/backend-sdk": "^1.0.1",
    "@vibecodeapp/proxy": "^2.0.1"
  },
  "devDependencies": {
    "@types/bun": "latest",
    "prisma": "6",
    "typescript": "5.8.3"
  }
}
```

---

## 10. Known Issues & Solutions

### CRITICAL: react-leaflet Incompatibility with React 18

**Problem**: `react-leaflet@5.0.0` has a critical incompatibility with React 18 that causes a white screen crash.

**Error Messages**:
```
Warning: Rendering <Context> directly is not supported and will be removed in a future major release.
Warning: A context consumer was rendered with multiple children...
Uncaught TypeError: render2 is not a function at updateContextConsumer
```

**Root Cause**: react-leaflet internally renders `<Context>` (the context object itself) instead of `<Context.Consumer>` or using the `useContext` hook. This is incompatible with React 18's stricter context handling.

**Failed Solutions**:
1. Using `<Fragment>` instead of `<div>` to wrap map children - did not fix the issue
2. Updating react-leaflet - no compatible version available

**Working Solution**: Use native Leaflet directly instead of react-leaflet.

```typescript
// TrailMap.tsx - CORRECT IMPLEMENTATION
import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export function TrailMap({ entries, height }: TrailMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  // Initialize map once
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const map = L.map(mapRef.current).setView([34.6266, -84.1934], 10);
    mapInstanceRef.current = map;

    L.tileLayer("https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png", {
      attribution: '...',
      maxZoom: 17,
    }).addTo(map);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update markers when entries change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear old markers, add new ones
    // ... implementation
  }, [entries]);

  return (
    <div style={{ height }}>
      <div ref={mapRef} style={{ height: "100%", width: "100%" }} />
    </div>
  );
}
```

**Key Pattern**:
- Use `useRef` for both the container div AND the map instance
- Initialize map in first `useEffect` with empty deps `[]`
- Update markers/layers in second `useEffect` with `[entries]` dep
- Clean up with `map.remove()` in return function

### Leaflet Marker Icons Not Loading

**Problem**: Default marker icons don't load in Vite builds.

**Solution**: Use CDN URLs for marker icons:

```typescript
const iconUrl = "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png";
const iconRetinaUrl = "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png";
const shadowUrl = "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png";

const DefaultIcon = L.icon({
  iconUrl,
  iconRetinaUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;
```

### Leaflet CSS Not Loading

**Problem**: Map tiles load but controls/popups look broken.

**Solution**: Import CSS in component OR in index.css:

```typescript
// Option 1: In component
import "leaflet/dist/leaflet.css";

// Option 2: In index.css
@import 'leaflet/dist/leaflet.css';
```

### Better Auth Email OTP Endpoints

**Problem**: Initial implementation used wrong endpoint paths for Better Auth email OTP flow.

**Wrong Endpoints**:
- `/api/auth/sign-in/email-otp` (for sending OTP) - returned validation error
- `/api/auth/email-otp/verify-email` (for verifying) - returned "Invalid OTP"

**Correct Endpoints**:
- **Send OTP**: `POST /api/auth/email-otp/send-verification-otp` with `{ email, type: "sign-in" }`
- **Verify OTP**: `POST /api/auth/sign-in/email-otp` with `{ email, otp }`

**Key Insight**: The send and verify endpoints have different path structures in Better Auth's email OTP plugin.

---

## 11. Current Status

### Completed Features

| Feature | Status | Notes |
|---------|--------|-------|
| Project setup | Done | Vite + React + Tailwind |
| Design system | Done | Custom trail-themed colors |
| Navbar | Done | Responsive with auth UI |
| Homepage | Done | Hero, stats, map, latest entry |
| Timeline page | Done | Chronological entry list |
| Entry detail page | Done | Full entry with photos |
| Stats component | Done | Progress bar + stat cards |
| TrailMap component | Done | Native Leaflet (not react-leaflet) |
| Mock data | Done | One sample entry |
| Backend API | Done | Full CRUD for entries |
| Database schema | Done | Users, entries, photos |
| Authentication backend | Done | Better Auth with email OTP |
| **Auth context** | Done | React context for auth state |
| **Login page** | Done | Email + OTP two-step flow |
| **Navbar auth UI** | Done | Sign in/out, user dropdown |
| **API client** | Done | Typed fetch wrapper |
| **React Query hooks** | Done | useEntries, useStats, mutations |
| **ProtectedRoute** | Done | Auth guard component |

### Not Yet Implemented

| Feature | Priority | Notes |
|---------|----------|-------|
| Entry creation UI | High | Form to add new entries |
| Entry editing UI | High | Edit existing entries |
| Connect pages to API | Medium | Replace mock data with live data |
| Photo upload | Medium | Connect to backend photo routes |
| Public/private entries | Medium | Visibility toggle |
| Full AT GPX route | Low | Display entire trail on map |
| Offline mode | Low | Service worker caching |
| Google Drive sync | Low | Third-party integration |

---

## 12. Next Steps

### Phase 1: Entry Management UI (Priority: HIGH)

#### Step 1.1: Entry Creation Form
Build form with:
- Date picker
- Title input
- Markdown editor (or textarea)
- Miles/elevation inputs
- GPS coordinate inputs (optional)
- Save button with loading state

#### Step 1.2: Entry Editing
- Edit button on entry detail page
- Pre-populated form with existing data
- Update mutation with optimistic updates

#### Step 1.3: Entry Deletion
- Delete confirmation dialog
- Delete mutation
- Redirect after delete

### Phase 2: Connect Pages to API (Priority: MEDIUM)

#### Step 2.1: Replace Mock Data
Update pages to fetch from API for authenticated users:

```typescript
// HomePage.tsx
const { isAuthenticated } = useAuth();
const { data: entriesData, isLoading } = useEntries(1, 50);

// Use API data if authenticated, mock data otherwise
const entries = isAuthenticated && entriesData
  ? entriesData.entries
  : mockJournalEntries;
```

#### Step 2.2: Loading States
Add skeleton loaders during data fetching

#### Step 2.3: Error Handling
Display error messages when API calls fail

### Phase 3: Photo Management (Priority: MEDIUM)

#### Step 3.1: Photo Upload Component
- Drag-and-drop upload
- Progress indicator
- Preview before upload
- Caption input

#### Step 3.2: Photo Gallery
- Grid display
- Lightbox view
- Reorder capability
- Delete functionality

### Phase 4: Enhanced Features (Priority: LOW)

#### Step 4.1: Full AT Route Display
- Load full GPX file (312k points)
- Optimize for performance (simplify line)
- Show progress along full trail

#### Step 4.2: Public/Private Entries
- Add `isPublic` field to schema
- Toggle on entry form
- Public viewing without auth

#### Step 4.3: Offline Support
- Service worker for caching
- IndexedDB for offline entries
- Sync when online

---

## Appendix: Environment Variables

### Backend (.env)
```env
DATABASE_URL="file:./prisma/dev.db"
BETTER_AUTH_SECRET="your-secret-here"
BACKEND_URL="https://your-backend-url.vibecode.run"
```

### Frontend (.env)
```env
VITE_BACKEND_URL="https://your-backend-url.vibecode.run"
```

---

## Appendix: Useful Commands

```bash
# Frontend
cd webapp
bun install
bun run dev          # Start dev server (port 8000)
bun run build        # Production build
bun run typecheck    # Type checking

# Backend
cd backend
bun install
bun run dev          # Start with hot reload (port 3000)
bunx prisma studio   # Database viewer
bunx prisma db push  # Push schema changes
bunx prisma generate # Regenerate client

# Testing API
curl $BACKEND_URL/health
curl $BACKEND_URL/api/entries -H "Cookie: ..."

# Testing Auth
curl -X POST $BACKEND_URL/api/auth/email-otp/send-verification-otp \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","type":"sign-in"}'
```

---

*End of Development Specification*
