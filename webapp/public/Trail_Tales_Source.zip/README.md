# Trail Tales - Appalachian Trail Journal

A beautiful web application for documenting your Appalachian Trail journey with interactive maps, journal entries, and progress tracking.

## Overview

Trail Tales is a mobile-first web app designed specifically for hikers tackling the Appalachian Trail. Record your daily adventures with markdown journals, photos, GPS tracks, and automatically visualize your progress on an interactive map of the entire 2,190-mile trail.

## Features

### Current Features (v1.0)
- **Interactive Trail Map**: Full Appalachian Trail route visualization using Leaflet.js with OpenTopoMap terrain tiles
- **Journal Entries**: Rich markdown support for daily journal entries with photos and statistics
- **Progress Tracking**: Visual progress indicator showing miles completed vs. remaining
- **Timeline View**: Beautiful chronological timeline of all your hiking days
- **Statistics Dashboard**: Track total miles, elevation gain, daily averages, and overall progress
- **Mobile Responsive**: Optimized for on-trail updates from your phone
- **GPX Support**: Display daily GPS tracks on the map

### Coming Soon
- **Google Drive Sync**: Auto-publish entries by dropping files into a cloud folder
- **Voice-to-Text**: Dictate journal entries on the trail
- **Photo Management**: Bulk upload and organize trail photos
- **Offline Mode**: Cache entries for areas without cell service
- **User Authentication**: Secure login to manage your journal
- **Public/Private Entries**: Choose which entries to share publicly

## Tech Stack

### Frontend (Port 8000)
- **Framework**: React 18 + Vite
- **Styling**: Tailwind CSS + shadcn/ui components
- **Maps**: Leaflet.js + react-leaflet
- **Markdown**: react-markdown with remark-gfm
- **Routing**: React Router v6
- **Type Safety**: TypeScript with Zod schemas

### Backend (Port 3000)
- **Runtime**: Bun
- **Framework**: Hono (lightweight, fast API)
- **Database**: SQLite + Prisma ORM
- **Authentication**: Better Auth (email + OTP)
- **Type Safety**: TypeScript + Zod validation

## Project Structure

```
/
├── webapp/                  # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   │   ├── Navbar.tsx
│   │   │   ├── TrailMap.tsx        # Interactive Leaflet map
│   │   │   ├── Stats.tsx           # Progress statistics
│   │   │   ├── JournalEntry.tsx    # Entry display component
│   │   │   └── Timeline.tsx        # Timeline view
│   │   ├── pages/          # Page components
│   │   │   ├── HomePage.tsx        # Map + stats overview
│   │   │   ├── TimelinePage.tsx    # All entries timeline
│   │   │   └── EntryDetailPage.tsx # Individual entry view
│   │   ├── data/           # Mock data (will be replaced with API)
│   │   │   └── journalEntries.ts
│   │   ├── index.css       # Design system & Tailwind config
│   │   └── App.tsx         # Main app with routing
│   └── public/
│       └── data/
│           └── appalachian_trail.gpx  # Full AT route (312k points)
│
└── backend/                # Backend API server
    ├── src/
    │   ├── routes/         # API route handlers
    │   │   ├── entries.ts  # Journal CRUD endpoints
    │   │   ├── photos.ts   # Photo upload endpoints
    │   │   └── stats.ts    # Statistics endpoints
    │   ├── types.ts        # Zod schemas for API contracts
    │   ├── auth.ts         # Better Auth configuration
    │   ├── prisma.ts       # Prisma client setup
    │   └── index.ts        # Hono app + middleware
    └── prisma/
        ├── schema.prisma   # Database schema
        └── dev.db          # SQLite database
```

## Design Philosophy

**Inspired by**: Strava (tracking), Notion (journaling), AllTrails (maps), National Park Service (aesthetics)

**Color Palette**:
- Forest greens (#4a7c59, #2d5016) - Primary
- Warm amber/orange (#f4a261, #e07a5f) - Accents
- Earthy cream (#faf9f6, #f5f5dc) - Backgrounds
- Deep charcoal (#2b2d42) - Text

**Typography**:
- Headings: "Outfit" (adventurous, modern)
- Body: "Inter" (clean, readable)

**Feel**: Rugged meets modern - like a digital trail journal with hand-drawn map aesthetics. Emphasis on beautiful photography, clean typography, and celebrating the journey.

## Data Model

### JournalEntry
- Date, day number, title
- Markdown content
- Location coordinates (lat/lon)
- Daily statistics (miles hiked, elevation gain)
- Cumulative progress (total miles completed)
- GPX track data
- Associated photos with captions

### Photo
- URL and caption
- Linked to journal entry
- Ordering for galleries

### User (Better Auth)
- Email authentication
- Secure session management

## API Endpoints

All endpoints follow the `{ data: ... }` envelope pattern.

**Journal Entries**:
- `GET /api/entries` - List all entries (paginated)
- `GET /api/entries/:id` - Get specific entry
- `POST /api/entries` - Create new entry
- `PUT /api/entries/:id` - Update entry
- `DELETE /api/entries/:id` - Delete entry

**Photos**:
- `POST /api/entries/:id/photos` - Upload photo to entry

**Statistics**:
- `GET /api/stats` - Overall trail statistics

**Authentication**:
- `POST /api/auth/sign-in` - Email OTP sign-in
- `POST /api/auth/sign-out` - Sign out
- `GET /api/auth/session` - Get current session

## Development

Both servers run automatically:
- **Frontend**: http://localhost:8000 (Vite dev server)
- **Backend**: http://localhost:3000 (Hono API server)

Changes to code hot-reload automatically.

## Adding Journal Entries

Currently using mock data in `webapp/src/data/journalEntries.ts`.

To add a new entry, add to the `mockJournalEntries` array:

```typescript
{
  id: "entry-2",
  dayNumber: 2,
  date: "2025-03-16",
  title: "Day 2: Hawk Mountain to Gooch Mountain",
  content: "# Your markdown content here...",
  milesHiked: 12.5,
  elevationGain: 2100,
  totalMilesCompleted: 20.3,
  location: "Gooch Mountain, GA",
  latitude: 34.6856,
  longitude: -84.2245,
  startPoint: { lat: 34.6723, lon: -84.2134 },
  endPoint: { lat: 34.6856, lon: -84.2245 },
  photos: [
    {
      url: "https://images.unsplash.com/photo-...",
      caption: "Beautiful sunrise"
    }
  ],
  gpxData: "<gpx>...</gpx>" // Optional
}
```

Later, these will be created through the API with authentication.

## Future Enhancements

### Phase 2 - Publishing Workflow
- Google Drive integration for easy mobile publishing
- Email-to-publish functionality
- Automated photo resizing and optimization

### Phase 3 - Advanced Features
- Social sharing (share individual entries or entire journey)
- Custom themes and branding
- Export entire journal as PDF or book
- Integration with fitness trackers (Suunto, Garmin)
- Weather data integration
- Elevation profiles and 3D terrain visualization

## Data Sources

- **Appalachian Trail GPX**: Sourced from [TopoFusion](https://topofusion.com/at-gps.php) (312,000 point full resolution track)
- **Map Tiles**: OpenTopoMap (free, no API limits)
- **Photos**: Unsplash (for demo content)

## Notes for Trail Use

- **Connectivity**: The app is designed to work with limited trail connectivity. Future versions will support offline mode.
- **Battery**: Map rendering can be battery-intensive. Consider downloading offline map tiles for your section.
- **Data Entry**: Voice-to-text feature coming soon to make journaling easier on the trail.
- **Backup**: Always backup your journal entries and photos to cloud storage.

---

Built with ❤️ for thru-hikers. Happy trails!
